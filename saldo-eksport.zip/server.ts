import express, { Request, Response, NextFunction } from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { initializeApp, getApps } from "firebase-admin/app";
import aiRouter from "./src/server/routes/ai";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";

dotenv.config();

const PORT = Number(process.env.PORT ?? 3000);

// Initialize Firebase Admin safely
if (getApps().length === 0) {
  const projectId = process.env.FIREBASE_PROJECT_ID || process.env.GCLOUD_PROJECT || process.env.GCP_PROJECT;
  if (!projectId) {
    console.warn("FIREBASE_PROJECT_ID not set. Firebase Admin initialized with default project credentials.");
  }
  try {
    initializeApp(projectId ? { projectId } : undefined);
  } catch (err) {
    console.warn("Failed to initialize Firebase Admin SDK:", err);
  }
}

async function startServer() {
  const app = express();

  // Security Middleware
  app.set("trust proxy", 1); // For express-rate-limit to work correctly behind proxy

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Use Helmet but configure CSP for Vite development and Firebase Auth
  app.use(helmet({
    contentSecurityPolicy: process.env.NODE_ENV === "production" ? {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'", "https://apis.google.com", "https://www.gstatic.com"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        connectSrc: ["'self'", "https://apis.google.com", "https://*.googleapis.com", "https://securetoken.googleapis.com", "https://firestore.googleapis.com", "https://identitytoolkit.googleapis.com"],
        frameSrc: ["'self'", "https://*.firebaseapp.com"],
        imgSrc: ["'self'", "data:", "blob:", "https://lh3.googleusercontent.com"],
      }
    } : false,
    crossOriginEmbedderPolicy: false
  }));

  // CORS configuration
  const allowedOrigins = process.env.ALLOWED_ORIGINS 
    ? process.env.ALLOWED_ORIGINS.split(",").map((s) => s.trim()).filter(Boolean)
    : [];

  app.use(cors({
    origin: (origin, callback) => {
      // Allow requests with no origin (like health checks, same-origin, curl)
      if (!origin) {
        return callback(null, true);
      }
      if (process.env.NODE_ENV === "production" && allowedOrigins.length > 0) {
        if (allowedOrigins.includes(origin) || allowedOrigins.includes("*")) {
          return callback(null, true);
        }
        console.warn(`CORS blocked request from origin: ${origin}`);
        return callback(null, false);
      }
      return callback(null, true);
    }
  }));

  // Global Rate Limiting (Basic)
  const globalLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 1000, // Limit each IP to 1000 requests per windowMs
    message: "Too many requests from this IP, please try again later",
    standardHeaders: true,
    legacyHeaders: false,
    validate: { xForwardedForHeader: false, trustProxy: false }
  });
  app.use(globalLimiter);

  app.use(express.json({ limit: "5mb" })); // Increased payload size to accommodate 3MB base64 images

  // Specific Rate Limiting for AI Endpoint
  const aiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 min
    max: 50, // Strict limit for AI API
    message: { error: "Zbyt wiele zapytań do API AI. Spróbuj ponownie później." },
    standardHeaders: true,
    legacyHeaders: false,
    validate: { xForwardedForHeader: false, trustProxy: false }
  });

  // AI Routes
  app.use("/api/ai", aiLimiter, aiRouter);

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production static files
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // Global Error Handler
  app.use((err: any, req: Request, res: Response, next: NextFunction) => {
    console.error("Unhandled Server Error:", process.env.NODE_ENV === "production" ? err.message : err.stack);
    const statusCode = err.status || 500;
    const message = process.env.NODE_ENV === "production" 
      ? "Wewnętrzny błąd serwera. Spróbuj ponownie później." 
      : err.message || "Błąd wewnętrzny.";
    
    res.status(statusCode).json({
      error: message
    });
  });

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
